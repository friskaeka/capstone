import React from "react";
import style from "./style.module.css";

const AdminFooter = () => {
  return <div className={style.footerContainer}>&copy; Sewakantor 2022</div>;
};

export default AdminFooter;
